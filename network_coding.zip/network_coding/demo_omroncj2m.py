
from socket import *
from time import ctime
import binascii
import mylog

log = mylog.myLog()

HOST = ''
PORT = 9600
BUFSIZE = 1024
ADDR = (HOST, PORT)

INFODATA1 = "46494e53000000100000000100000000000000ef00000005"
INFODATA2 = "46494e53000000720000000200000000c0000200efef0005000505010000434a324d2d43505533312020202020202020202030322e3031000000000030322e3130000000000000010000000000000000000000000000000000010000800180018001800000000000000000020100000a17800008010000000000"
INFODATA3 = "46494e53000000720000000200000000c0000200fbef00010005050100004350314c2d454d343044522d440000002020202030312e3030000000000030312e3038000000000000000000000000000000000000000000000000010000000000000000000000000000000000010100001417800008000000000000"

s = socket(AF_INET, SOCK_STREAM)
s.bind(ADDR)
s.listen(5)


while True:
    try:
        # print('Waiting for connection ....')
        log.info('Waiting for connection ...')
        conn, addr = s.accept()
        # print('Connected client from:%s:%s' %addr)
        log.info('Connected client from:%s:%s'%addr)
        while True:
            data = conn.recv(BUFSIZE)
            print(data)
            if not data:
                # print('not data')
                log.warning('no data')
                break
            else:
                # print('Client:%s '%data.encode('hex'))
                data_out = binascii.b2a_hex(data)
                # print(data_out)
                log.info('Client:%s '%data_out)
                if data_out == b'46494e530000000c000000000000000000000000':
                    # print('data is fins')
                    log.info('data in fins')
                    conn.sendall(binascii.a2b_hex(INFODATA1))
                    # print('send fins recv')
                    log.info('send fins recv')
                    data1 = conn.recv(BUFSIZE)
                    # print(data1.encode('hex'))
                    data1_out = binascii.b2a_hex(data1)
                    log.info(data1_out)
                    if data1_out == b'46494e530000001500000002000000008000020005000000ef05050100':
                        # print('data is find1')
                        log.info('data is find1')
                        conn.sendall(binascii.a2b_hex(INFODATA2))
                        log.info('response %s' % binascii.a2b_hex(INFODATA2))
                        # print('send dev_info\nCycle Over !')
                    else:
                        break
                else:
                    break
    except Exception as e:
        print('Error:%s',e)

s.close()
