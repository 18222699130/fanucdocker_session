# # -*- coding: utf-8 -*-
# # @Time    : 2018/8/21 上午9:32
# # @File    : TCP_client.py
# # @Software: PyCharm
#
import socket
import time
import binascii

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

# s.connect(('107.172.108.185',8193))
s.connect(('192.168.21.219',8193))
# # print(s.recv(1024).decode('utf-8'))
#
data1 = 'a0a0a0a00001010100020001'
s.send(binascii.a2b_hex(data1))
#
print(binascii.b2a_hex(s.recv(1024)))
s.close()
#第二次握手
s1 = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s1.connect(('192.168.21.219',8193))
# s1.connect(('107.172.108.185',8193))
data = ['a0a0a0a00001010100020002',
        # 'a0a0a0a000012101001e0001001c0001000100180000000000000000000000000000000000000000',
        # "a0a0a0a000012101001e0001001c00010001000500000008112100000000000000000000000000000000",
        # "a0a0a0a000012101001e0001001c0001000100050000000900000000000000000000000000000000"
        # 'a0a0a0a000012101001e0001001c0001000100050000270f00000000000000000000000000000000',
        'a0a0a0a000012101001e0001001c0001000100050000000f00000000000000000000000000000000',
        'a0a0a0a000012101001e0001001c0001000100050000000600000000000000000000000000000000'
        ]

# data = ['0300001611e00000000500c1020100c2020200c0010a',
#         '0300001902f08032010000000000080000f0000001000101e0',
#         '0300002102f080320700000000000800080001120411440100ff09000400110001',
#         '0300002102f080320700000000000800080001120411440100ff09000400110001'
# ]

# s1.send(binascii.a2b_hex(data[0]))
# if s1.recv(1024)!=0:
#     s1.send(binascii.a2b_hex(data[1]))
# else:
#     s1.send(binascii.a2b_hex(data[0]))
#
# time.sleep(0.5)
# s1.send(binascii.a2b_hex(data[2]))

for i in range(len(data)):
    s1.send(binascii.a2b_hex(data[i]))
    print(binascii.b2a_hex(s1.recv(1024)))
    # while s1.recv(1024) == 0:
    #     s1.send(binascii.a2b_hex(data[i]))
    # time.sleep(0.2)

# for i in data:
#     s1.send(binascii.a2b_hex(i))
#     # time.sleep(0.5)
#     recv = s.recv(1024)
#     if binascii.b2a_hex(recv):
#         print(binascii.b2a_hex(recv))
#     #     time.sleep(1)
#         continue
#     else:
#         print('error')
# s1.close()
# data1 = "a0a0a0a000012101001e0001001c0001000100050000000500000000000000000000000000000000"
# recv1 = s1.recv(1024)
# print(binascii.b2a_hex(recv1))

# s1.send(binascii.a2b_hex(data1))
# s.send(binascii.a2b_hex(data))
# s2.close()
# data_Name = [b'DAVID',b'Michael',b'Lucy']
#
# for data in [b'DAVID',b'Michael',b'Lucy']:
#     s.send(data)
#     print(s.recv(1024).decode('utf-8'))
# s.send(data)
# s.send(b'exit')
# s.close()
s1.close()
# 'a0a0a0a000012101001e0001001c0001000100050000000500000000000000000000000000000000'
# 'a0a0a0a0000421020012000100100001000100050005000200000000'
'''import socket
import time
import binascii
import threading
import mylog

logger = mylog.myLog()

def scan():
    ip1 = ''
    ip2 = ''
    ip3 = ''
    ip4 = ''
    for i in range(0,255):
        ip1 = i
        if ip1 in [0,10,172,192]:
            continue
        for j in range(0,255):
            ip2 = j
            for k in range(0,255):
                ip3 = k
                for l in range(0,255):
                    ip4 = l
                    ip = str(ip1) + '.' +str(ip2) + '.' + str(ip3) + '.' + str(ip4)
                    addr = soaddr_generate(ip, 8193)
                    connect_machine(addr, data)
                    print("thread %s is running"%ip)
                    # print(ip)
# port = 8193
# data = binascii.a2b_hex('a0a0a0a00001010100020001')

def soaddr_generate(ip,port):
    return (ip,port)

def connect_machine(addr,data):
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    # s.settimeout(5)
    try:
        s.connect(addr)
        s.send(data)
        recv_data = binascii.b2a_hex(s.recv(1024))
        if recv_data != '':
            logger.info(('maybe is numerical machine:%s', addr))
        else:
            logger.info(('%s is not a numerical machine',addr))
        if  data != 'a0a0a0a000040102016800060005000100200008000a00030003000200020000000100010000000100000000000000000000204d000100000002000200000001000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000':
            logger.warning(('%s is a numerical machine', addr))
        else:
            logger.info(('%s is not a numerical machine',addr))
        s.close()
    except Exception as e:
        s.close()
        # print(e)
        # logger.error(('%s is not a numerical machine',addr))
# while True:
# class scanner(threading.Thread):
#     tlist = []  # 用来存储队列的线程
#     maxthreads = 1000  # int(sys.argv[2])最大的并发数量，此处我设置为100，测试下系统最大支持1000多个
#     evnt = threading.Event()  # 用事件来让超过最大线程设置的并发程序等待
#     lck = threading.Lock()  # 线程锁
#
#     def __init__(self):
#         threading.Thread.__init__(self)
#
#     def run(self):
#         try:
#             pass
#         except Exception as e:
#             print(e)
#         # 以下用来将完成的线程移除线程队列
#         scanner.lck.acquire()
#         scanner.tlist.remove(self)
#         # 如果移除此完成的队列线程数刚好达到99，则说明有线程在等待执行，那么我们释放event，让等待事件执行
#         if len(scanner.tlist) == scanner.maxthreads - 1:
#             scanner.evnt.set()
#             scanner.evnt.clear()
#         scanner.lck.release()
#
#     def newthread():
#         scanner.lck.acquire()  # 上锁
#         sc = scanner()
#         scanner.tlist.append(sc)
#         scanner.lck.release()  # 解锁
#         sc.start()
#
#     # 将新线程方法定义为静态变量，供调用
#     newthread = staticmethod(newthread)
#
#
# def runscan():
#     for i in range(0,1000):
#         scanner.lck.acquire()
#         # 如果目前线程队列超过了设定的上线则等待。
#         if len(scanner.tlist) >= scanner.maxthreads:
#             scanner.lck.release()
#             scanner.evnt.wait()  # scanner.evnt.set()遇到set事件则等待结束
#             print('waiting')
#         else:
#             scanner.lck.release()
#         scanner.newthread()
#
#     for t in scanner.tlist:
#         t.join()  # join的操作使得后面的程序等待线程的执行完成才继续



if __name__ == "__main__":
    # runscan()
    data = binascii.a2b_hex('a0a0a0a00001010100020001')
    port = 8193
    # ip1 = ''
    # ip2 = ''
    # ip3 = ''
    # ip4 = ''
    # for i in range(0, 255):
    #     ip1 = i
    #     if ip1 in [0, 10, 172, 192]:
    #         continue
    #     for j in range(0, 255):
    #         ip2 = j
    #         for k in range(0, 255):
    #             ip3 = k
    #             runscan()
    #             for l in range(0, 255):
    #                 ip4 = l
    #                 ip = str(ip1) + '.' + str(ip2) + '.' + str(ip3) + '.' + str(ip4)
    #                 addr = soaddr_generate(ip, port)
    #                 connect_machine(addr,data)
    while True:
        t = threading.Thread(target=scan,name='scan')
        t.start()
        t.join()'''
