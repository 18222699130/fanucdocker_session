# -*- coding: utf-8 -*-
# @Time    : 2018/9/26 下午4:17
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : one_for_more_port.py
# @Software: PyCharm

import socket
#
# s1 = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
import demo_cr3
import demo_enip
import demo_fox


if __name__ == "__main__":
    addr1 = ('192.168.127.94', 8190)
    addr2 = ('192.168.127.94', 8191)
    addr3 = ('192.168.127.94', 8192)
    s1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s1.bind(addr1)
    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s2.bind(addr2)
    s3 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s3.bind(addr3)
    s1.listen()
    s2.listen()
    s3.listen()
    ip_addr = demo_fox.get_host_ip()
    demo_fox.openfox(ip_addr)
    demo_enip.openEnip(ip_addr)
    demo_cr3.opencr3(ip_addr)

'''
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # s.bind(('192.168.127.94', 8193))
    s.bind((ip, port))
    # 设置最大连接数
    s.listen(100)
'''