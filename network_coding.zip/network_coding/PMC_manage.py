# -*- coding: utf-8 -*-
# @Time    : 2018/10/25 下午4:44
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : PMC_manage.py
# @Software: PyCharm
'''
此文件主要完成对PMC数据的管理
主要包括：
PMC 读取、写入、定时、报警
重点：PMC标头数据即为机床厂家相关信息
'''
from scapy.all import *
import binascii
import os
import pymysql

# root_dir = 'data/pmc_relative'
# # pcaps = rdpcap('data/pmc_relative/get_all_alarm.pcapng')
# # functions = 'get_all_alarm'
# dict_all = []


def get_all_pcapng(path):
    """

    :param path:
    :return: 返回一个list，是当前目录下的pcapng文件
    """
    #对generator并不熟悉，而os.walk返回的是一个generator，却又无法使用next(),简直要疯了
    for root,dirs,files in os.walk(path):
        return files

def get_functions(file):
    """

    :param file:
    :return:返回一个该文件对应的function，之前的包的命名是按功能命的，故直接用简单正则提取即可
    """
    return re.findall(r'(.+).pcapng',file)[0]

def openpcapng(root,file):
    """

    :param root: 上层路径
    :param file: 当前文件名
    :return: 返回一个打开的句柄
    """
    filepath = root + '/' + file
    return rdpcap(filepath)


def get_dict_element(pcapdata,func,dict_all):
    length = len(pcapdata)
    if length%2 == 0:
        data = {}
        for i in range(length):
            payload = binascii.b2a_hex(pcapdata[i][Raw].load)
            if i%2 == 0:
                data['request_data'] = bytes.decode(payload)
            else:
                data['response_data'] = bytes.decode(payload)
                dict_all.append(data)
                data = {}
            data['functions'] = func
        return True
    else:
        print("length is a odd: %d"%length)
        return False
def createsql(dict_data):
    sqlclause = "INSERT IGNORE INTO session(request_data,response_data,functions)VALUES"
    values = (dict_data['request_data'],dict_data['response_data'],dict_data['functions'])
    sqlclause += str(values)
    print(sqlclause)
    return sqlclause

def write_to_database(dict_all):
    db = pymysql.connect("localhost", "root", "lsj940411", "fanucdocker")
    print(db)
    # db = pymysql.connect(**config)
    if db:
        print('connect success')
    cursor = db.cursor()

    for i in dict_all:
        sql = createsql(i)
        # SQL 插入语句
        # sql = "INSERT IGNORE INTO session(request_data,response_data,functions)VALUES('a0a0a0a000012101001e0001001c0001000100030000000100000000000000000000000000000000','a0a0a0a0000421020012000100100001000100030000000200000000','search')"
        try:
            # 执行sql语句
            cursor.execute(sql)
            # cursor.execute(sql1)
            # results = cursor.fetchall(sql1)
            # print(results)
            # 提交到数据库执行
            db.commit()
        except Exception as e:
            print(e)
            # Rollback in case there is any error
            db.rollback()

    # 关闭数据库连接
    db.close()

if __name__ == "__main__":
    root_dir = 'data/pmc_relative'
    dict_all = []

    files = get_all_pcapng(root_dir)
    #生成dict_all
    for file in files:
        functions = get_functions(file)
        pcap_data = openpcapng(root_dir,file)
        if get_dict_element(pcap_data,functions,dict_all):
            pass
        else:
            print("the error pcap is : %s"%functions)

    #写入数据库
    write_to_database(dict_all)

