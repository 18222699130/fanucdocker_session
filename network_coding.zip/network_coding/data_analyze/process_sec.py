# -*- coding: utf-8 -*-
# @Time    : 2018/12/17 上午10:32
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : process_sec.py
# @Software: PyCharm

import json
from io import StringIO
import re
import copy

"""
本脚本的目的是：
1. 在第一次筛选数据的基础上，去重，写到process_data1.txt中
2. 将请求和响应分成两个文件，且将function更加简化，之前壮壮的标注实在让人无语
3. 然后再决定是否进一步处理，比如将每一个请求当做一个点，
建立路径（但我觉得没必要做路径分析，这些调用都属于常规调用，异常的请求判断规则很好写）
"""
def get_dict(str_data):
    """
    将json文件转为dict
    :param str_data:
    :return:
    """
    io1 = StringIO(str_data)
    return json.load(io1)

file = open('../data/process_data.txt','r')
file1 = open('../data/process_data1.txt','w')
file2 = open('../data/data_with_correct_func.txt','w')

data_redundant = {'a0a0a0a00001010100020001':0,'a0a0a0a00001010100020002':0,
                  'a0a0a0a000012101001e0001001c0001000100180000000000000000000000000000000000000000':0,
                  'a0a0a0a0000102010000':0}
numlen = [24, 80, 20, 192, 1052, 156, 96, 2720, 104]
data_all = []
data_no_func = []
data_part = []
functions = []
request_data = []
request_data_len = []
response_data = []
response_data_len = []

def get_file_path(num):
    path = '../data/data_classified_by_length/' + 'request_len_' + str(num) + '.txt'
    return path


def analyze(dictline):
    """
    原本去重考虑的是去掉连接部分的三个前缀数据包（8429条）
    :param dictline:
    :return:
    """
    a = get_dict(dictline)

    if a['request_data'] in data_redundant and data_redundant[a['request_data']] < 1:
        b = json.dumps(a)
        file1.write('\n')
        file1.write(b)
        data_redundant[a['request_data']] += 1

        print(data_redundant[a['request_data']])
    elif a['request_data'] not in data_redundant:
        b = json.dumps(a)
        file1.write('\n')
        file1.write(b)
    else:
        print(data_redundant[a['request_data']])


def analyze1(dictline):
    """
    后来发现去掉并没有少多少，故看数据还有很多重合的数据，这个用常用的去重算法去重（3618条）
    :param dictline:
    :return:
    """
    a = get_dict(dictline)
    if a not in data_all:
        data_all.append(a)
    else:
        pass

def analyze2(dictline):
    """
    在此之前发现数据少了一半，但还有数据重复，进一步发现应该将数据中的function去掉后，再做去重，然后对照总体表，
    把该字段补上(3552条)现在的数据在data_with_correct_func.txt中，数据没有重复的，且function字段已简化
    :param dictline:
    :return:
    """
    a = get_dict(dictline)

    b = a.pop('functions')
    d = copy.deepcopy(a)
    #此处修改后，不只是简单去掉function，而是尝试替换function，将其简化
    try:
        c = re.findall(r'\+(.+)',b)
        a['functions'] = c[0]
    except Exception as e:
        print(e)

    if b not in functions:
        functions.append(b)
    else:
        pass
    if a not in data_part and a['functions']!='' and d not in data_no_func:
        data_part.append(a)
        data_no_func.append(d)
    else:
        pass

def countrequest(dictline):
    a = get_dict(dictline)['request_data']
    length = len(a)
    if a not in request_data:
        request_data.append(a)
    else:
        pass
    if length not in request_data_len:
        request_data_len.append(length)

def countresponse(dictline):
    a = get_dict(dictline)['response_data']
    length = len(a)
    if a not in response_data:
        response_data.append(a)
    else:
        pass
    if length not in response_data_len:
        response_data_len.append(length)


def writeinfile(dictofdata,filehandle):
    for i in dictofdata:
        b = json.dumps(i)
        filehandle.write('\n')
        filehandle.write(b)


if __name__ == "__main__":
    line = file.readline()
    """
    先去重生成对照列表
    """
    while line:
        # analyze(line)
        analyze2(line)
        countrequest(line)
        countresponse(line)
        line = file.readline()

    """
    再给未加function的数据加标签
    """
    writeinfile(data_part,file2)

    # print("count of distinct data: ",len(data_part))
    print("count of functions is: ",len(functions))
    print("functions are: ",functions)
    print("count of distinct request_data:",len(request_data))
    print("count of distinct length of request_data:",len(request_data_len))
    print("request length are:",request_data_len)
    print("count of distinct response_data:",len(response_data))
    print("count of distinct length of response_data:",len(response_data_len))
    print("response length are:",response_data_len)
    """
    #这段代码是之前筛选去掉"连接和断开连接"这几种请求的
        a = get_dict(line)
    
        if a['request_data'] not in data_redundant or data_redundant[a['request_data']] <= 1:
    
            b = json.dumps(a)
            file1.write('\n')
            file1.write(b)
        else:
            data_redundant[a['request_data']] += 1
            print(data_redundant[a['request_data']])
            pass
    """
    """
    这段是将不同请求长度的数据分别写入不同的文件中
    """
    for num in numlen:
        path = get_file_path(num)
        file_temp = open(path, 'w')
        for i in data_part:
            if len(i['request_data']) == num:

                file_temp.write('\n')
                file_temp.write(json.dumps(i))

        file_temp.close()

    file.close()
    file1.close()
    file2.close()
    # newline = json(line)
    # print(json.loads(line)['request_data'])
    # print(line)

