# -*- coding: utf-8 -*-
# @Time    : 2018/12/18 下午2:35
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : compare_string.py
# @Software: PyCharm

# from data_analyze import process_sec
from io import StringIO
import json
def get_dict(str_data):
    """
    将json文件转为dict
    :param str_data:
    :return:
    """
    io1 = StringIO(str_data)
    return json.load(io1)

"""
这是一个简单的，不具有算法的协议逆向小工具，目的是得到一个model
长度分别是[24, 80, 20, 192, 1052, 156, 96, 2720, 104]
"""
data1 = 'a0a0a0a000012101001e0001001c00010001002600000004ffffffff000000000000000000000000'
data2 = 'a0a0a0a000012101001e0001001c0001000100260000000400000001000000000000000000000000'

file = open('../data/data_classified_by_length/request_len_80.txt','r')
file1 = open('../data/process_data1.txt','r')
line = file.readline()
print(line)
"""
以下是对比function的request_data，得到每个function的可变字段，不同function并没有对比
"""
data_dict = get_dict(line)
data = data_dict['request_data']
model = list(data)
count = 0
while line:
    #一个保持原有状态，一个是最新的状态，模拟指针的运算，先判断function是否不一致，再去对比数据，最后向下移动指针
    data_temp_dict = get_dict(line)
    data_temp = list(data_temp_dict['request_data'])
    # print(data_temp_dict['request_data'])
    if data_temp_dict['functions'] != data_dict['functions']:
        print(''.join(model), ' function: ', data_dict['functions'])
        count += 1
        data_dict = data_temp_dict
        data = data_dict['request_data']
        model = list(data)
    else:
        pass
    for i in range(len(model)):
        if model[i] == data_temp[i]:
            pass
        else:

            model[i] = "-"

    # print(''.join(model), ' function: ', data_temp_dict['functions'])

    line = file.readline()
print(''.join(model), ' function: ', data_dict['functions'])
print(count)
file.close()
file1.close()