# -*- coding: utf-8 -*-
# @Time    : 2018/12/18 下午4:57
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : test.py
# @Software: PyCharm
# from data_analyze import process_sec
from io import StringIO
import json

def get_dict(str_data):
    """
    将json文件转为dict
    :param str_data:
    :return:
    """
    io1 = StringIO(str_data)
    return json.load(io1)
file = open('../data/process_data1.txt','r')
line = file.readline()
print(line)


"""
以下是对比function的request_data，得到每个function的可变字段，不同function并没有对比
"""
data_dict = get_dict(line)
data = data_dict['request_data']
model = list(data)
count = 0
while line:
    #一个保持原有状态，一个是最新的状态，模拟指针的运算，先判断function是否不一致，再去对比数据，最后向下移动指针
    data_temp_dict = get_dict(line)
    data_temp = list(data_temp_dict['request_data'])
    # print(data_temp_dict['request_data'])
    if data_temp_dict['functions'] != data_dict['functions']:
        print(''.join(model), ' function: ', data_dict['functions'])
        count += 1
        data_dict = data_temp_dict
        data = data_dict['request_data']
        model = list(data)
    elif len(model) == len(data_temp):
        for i in range(len(model)):
            if model[i] == data_temp[i]:
                pass
            else:

                model[i] = "-"
    else:
        print(''.join(model), ' function: ', data_dict['functions'])
        # count += 1
        data_dict = data_temp_dict
        data = data_dict['request_data']
        model = list(data)

    # print(''.join(model), ' function: ', data_temp_dict['functions'])

    line = file.readline()
print(''.join(model), ' function: ', data_dict['functions'])
print(count)
file.close()
