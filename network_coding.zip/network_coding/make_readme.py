# -*- coding: utf-8 -*-
# @Time    : 2018/9/4 下午5:19
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : make_readme.py
# @Software: PyCharm

# import classify
# import connect_database
# import docker_mysql
# import NC_TCPclient
import NC_TCPserver

# print(help(classify))
a = help(NC_TCPserver)
