# -*- coding: utf-8 -*-
# @Time    : 2018/10/25 下午4:47
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : Message_manage.py
# @Software: PyCharm
'''
此文件主要完成对message信息的获取和管理
一、一般信息
警报状态、获取报警、清楚报警
获取信息（什么信息？）
机器的状态
程序启动的信息

二、维护信息
机床的获取
状态的获取
机床维修项目的录入
名称、生命、剩余信息的录入
'''
#专门的一个信息库用来存储message相关的报文
import pymysql

def createsql(dict_data):
    sqlclause = "INSERT IGNORE INTO session(request_data,response_data,functions)VALUES"
    values = (dict_data['request_data'],dict_data['response_data'],dict_data['functions'])
    sqlclause += str(values)
    print(sqlclause)
    return sqlclause

# config = {
#     'host': '127.0.0.1',
#     'port': 3306,
#     'db':'fanucdocker',
#     'user': 'root',
#     'passwd': 'lsj940411',
#     }

dict_all = [{
    'request_data':'a0a0a0a000012101001e0001001c00020001800b0000000000000000000000000000000000000000',
    'response_data':'a0a0a0a00005210201120001011000020001800b000000000000010054535547414d4920434f52504f524154494f4e20202020202020202020202020423031322f32302d342f352d3320202020202020202020202020202020202020465330692d544620262030692d4620504d432020202020202020202020202020454330353030333237332d454330353020202020202020202020202020202020202020202020323031372e31302e323020202020202054535547414d49204e4147414f4b4120504c414e54202020202020202020202054535547414d49204e4147414f4b4120504c414e542020202020202020202020424153453a453930352d3130202020202020202020202020202020202020202030202020303820202020',
    'functions':'get_machine_info'
},]
db = pymysql.connect("localhost","root","lsj940411","fanucdocker")
print(db)
# db = pymysql.connect(**config)
if db:
    print('connect success')
cursor = db.cursor()

for i in dict_all:
    sql = createsql(i)
# SQL 插入语句
# sql = "INSERT IGNORE INTO session(request_data,response_data,functions)VALUES('a0a0a0a000012101001e0001001c0001000100030000000100000000000000000000000000000000','a0a0a0a0000421020012000100100001000100030000000200000000','search')"
    try:
       # 执行sql语句
       cursor.execute(sql)
       # cursor.execute(sql1)
       # results = cursor.fetchall(sql1)
       # print(results)
       # 提交到数据库执行
       db.commit()
    except Exception as e:
        print(e)
       # Rollback in case there is any error
        db.rollback()

# 关闭数据库连接
db.close()