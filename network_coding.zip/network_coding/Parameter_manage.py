# -*- coding: utf-8 -*-
# @Time    : 2018/10/25 下午4:36
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : Parameter_manage.py
# @Software: PyCharm
'''
此文件针对参数相关而设
主要包括：读取参数、修改参数等
'''