# -*- coding: utf-8 -*-
# @Time    : 2019/1/12 下午8:10
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : test_argparse.py
# @Software: PyCharm

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("-v","--version",help="increase output verbosity")
args = parser.parse_args()
if args.version:
    print('version is %s'%args.version)

