__title__ = 'oschameleon'
__version__ = '0.1.2'