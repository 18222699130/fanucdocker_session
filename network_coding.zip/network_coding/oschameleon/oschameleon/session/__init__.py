
from session import Session

session_ = Session()


def get_Session():
    return session_
