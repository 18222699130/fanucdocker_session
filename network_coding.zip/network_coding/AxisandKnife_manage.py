# -*- coding: utf-8 -*-
# @Time    : 2018/10/25 下午4:38
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : AxisandKnife_Manage.py
# @Software: PyCharm

'''
此文件主要完成
1）对轴信息的获取：包括相对位置、绝对位置、机器位置、剩余走的量、主轴和伺服轴的负载信息

2）对刀具进行管理：读取刀组、刀补偿、设置刀组、删除刀组（后两个在现实其情况尚无法做到，无采集信息，不知从何做起）
'''

