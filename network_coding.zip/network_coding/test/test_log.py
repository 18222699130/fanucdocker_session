# -*- coding: utf-8 -*-
# @Time    : 2019/1/10 上午10:59
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : test_log.py
# @Software: PyCharm
# import logging
# import logstash
#
# # AMQP parameters
# host = 'localhost'
# username = 'guest'
# password= 'guest'
# exchange = 'logstash.py'
#
# # get a logger and set logging level
# test_logger = logging.getLogger('python-logstash-logger')
# test_logger.setLevel(logging.INFO)
#
# # add the handler
# test_logger.addHandler(logstash.AMQPLogstashHandler(version=1,
#                                                     host=host,
#                                                     durable=True,
#                                                     username=username,
#                                                     password=password,
#                                                     exchange=exchange))
#
# # log
# test_logger.error('python-logstash: test logstash error message.')
# test_logger.info('python-logstash: test logstash info message.')
# test_logger.warning('python-logstash: test logstash warning message.')
#
# try:
#     1/0
# except:
#     test_logger.exception('python-logstash: test logstash exception with stack trace')
import json
a = {
    'timestamp':'',
    'warningtype':'',
    'protocol':'',
    'detail':{
            'src':'',
            'src_port':'',
            'dst':'',
            'dst_port':'',
            'request_function':'',
            'warn_level':''
            }
    }

print(json.dumps(a))
file1 = open('./test.json','w')
file1.write(json.dumps(a))