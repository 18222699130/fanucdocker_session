# -*- coding: utf-8 -*-
# @Time    : 2018/11/14 下午3:12
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : pcap_demo.py
# @Software: PyCharm
import pcapy
import sys
from scapy.all import *

# p=srloop(IP(dst='192.168.126.246')/TCP(dport=8081,sport=8082))
# if p:
#     p.show()

# '''
# ARP探测
# '''
# conf.verb=0#设置冗长度，0最小，3最大
# ans,unans=srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst="192.168.126.0/24"),timeout=2)
#
# print(r"\begin{tabular}{|l|l|}")
# print(r"\hline")
# print(r"MAC & IP\\")
# print(r"\hline")
# print(ans)
# for snd,rcv in ans:
#     print(rcv.sprintf(r"%Ether.src% & %ARP.psrc%\\"))
# print("another")
# for snd1 in unans:
#     print(snd1,"&")
#     '''
#     只能借助spintf()方法输出结果，不知道如何单独提取mac地址和ip地址，如何做？
#     '''
# print(unans)
# print(r"\hline")
# print(r"\end{tabular}")
# # dpkts = sniff(iface='en0',count=100)
# # for i in dpkts:


"""
端口扫描
"""

syn = IP(dst='192.168.126.249',flags=2,ttl=128)/TCP(dport=(1,200),flags=2)
#IP()中flags设置了分片位，0代表不分片，2代表分片，3代表更多分片，后边Fragment offse设置分片个数
#TCP()中设置
result_raw = sr(syn,timeout=1,verbose=False)
result_list = result_raw[0].res
for i in range(len(result_list)):
    if result_list[i][1].haslayer(TCP):
        TCP_filed = result_list[i][1].getlayer(TCP).fields
        if TCP_filed['flags'] == 18:
            print(TCP_filed['sport'],'is open')
# print(result_raw)

