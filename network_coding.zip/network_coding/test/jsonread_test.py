# -*- coding: utf-8 -*-
# @Time    : 2019/1/11 上午10:29
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : jsonread_test.py
# @Software: PyCharm
import json

data = open('../MyLog/MingData.json','r')

data_str = json.loads(data.readline())

print(json.loads(data))

