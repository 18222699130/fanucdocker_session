# -*- coding: utf-8 -*-
# @Time    : 2019/1/10 下午4:02
# @Author  : shijie luan
# @Email   : lsjfy0411@163.com
# @File    : json_test.py
# @Software: PyCharm
import json
import copy
import time
model = {
    'timestamp':'',
    'warningtype':'',
    'protocol':'',
    'detail':{
            'src':'',
            'src_port':'',
            'dst':'',
            'dst_port':'',
            'RequestFunction':'',
            'WarnLevel':''
            }
    }

def makelogdict(ip_addr,addr,warningtype,requestfunction,WarnLevel='normal',protocol='FOCAS2'):
    dictlog = copy.deepcopy(model)
    dictlog['timestamp'] = time.asctime()
    dictlog['protocol'] = protocol
    dictlog['warningtype'] = warningtype
    #此处的warningtype就是function，对应服务的某种服务????
    dictlog['detail']['src'] = addr[0]
    dictlog['detail']['src_port'] = addr[1]
    dictlog['detail']['dst'] = ip_addr
    dictlog['detail']['dst_port'] = 8193
    dictlog['detail']['RequestFunction'] = requestfunction
    dictlog['detail']['WarnLevel'] = WarnLevel
    return dictlog

a = makelogdict('192.168.127.94',('192.168.127.94',12133),'warning','connect')
print(json.dumps(a))